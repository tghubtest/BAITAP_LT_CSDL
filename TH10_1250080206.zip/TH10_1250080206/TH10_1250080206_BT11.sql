DROP TABLE Nhap CASCADE CONSTRAINTS;
DROP TABLE Xuat CASCADE CONSTRAINTS;
DROP TABLE PNhap CASCADE CONSTRAINTS;
DROP TABLE PXuat CASCADE CONSTRAINTS;
DROP TABLE SanPham CASCADE CONSTRAINTS;
DROP TABLE HangSX CASCADE CONSTRAINTS;
DROP TABLE NhanVien CASCADE CONSTRAINTS;

CREATE TABLE HangSX (
    MaHangSX VARCHAR2(10) PRIMARY KEY,
    TenHang VARCHAR2(50),
    DiaChi VARCHAR2(100),
    SoDT VARCHAR2(20),
    Email VARCHAR2(50)
);

CREATE TABLE SanPham (
    MaSP VARCHAR2(10) PRIMARY KEY,
    MaHangSX VARCHAR2(10) REFERENCES HangSX(MaHangSX),
    TenSP VARCHAR2(50),
    SoLuong NUMBER(10),
    MauSac VARCHAR2(20),
    GiaBan NUMBER(15,2),
    DonViTinh VARCHAR2(20),
    MoTa VARCHAR2(100)
);

CREATE TABLE NhanVien (
    MaNV VARCHAR2(10) PRIMARY KEY,
    TenNV VARCHAR2(50),
    GioiTinh VARCHAR2(10),
    DiaChi VARCHAR2(100),
    SoDT VARCHAR2(20),
    Email VARCHAR2(50),
    TenPhong VARCHAR2(50)
);

CREATE TABLE PNhap (
    SoHDN VARCHAR2(10) PRIMARY KEY,
    NgayNhap DATE,
    MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV)
);

CREATE TABLE Nhap (
    SoHDN VARCHAR2(10) REFERENCES PNhap(SoHDN),
    MaSP VARCHAR2(10) REFERENCES SanPham(MaSP),
    SoLuongN NUMBER(10),
    DonGiaN NUMBER(15,2),
    CONSTRAINT pk_Nhap PRIMARY KEY (SoHDN, MaSP)
);


CREATE TABLE PXuat (
    SoHDX VARCHAR2(10) PRIMARY KEY,
    NgayXuat DATE,
    MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV)
);

CREATE TABLE Xuat (
    SoHDX VARCHAR2(10) REFERENCES PXuat(SoHDX),
    MaSP VARCHAR2(10) REFERENCES SanPham(MaSP),
    SoLuongX NUMBER(10),
    CONSTRAINT pk_Xuat PRIMARY KEY (SoHDX, MaSP)
);


INSERT INTO HangSX VALUES ('H01', 'Apple', 'California, USA', '19001552', 'contact@apple.com');
INSERT INTO HangSX VALUES ('H02', 'Samsung', 'Seoul, Korea', '18005888', 'support@samsung.com');
INSERT INTO HangSX VALUES ('H03', 'Xiaomi', 'Beijing, China', '19006067', 'service.vn@xiaomi.com');

INSERT INTO NhanVien VALUES ('NV01', 'Phạm Thị Trang', 'Nữ', 'Quận 1, HCM', '0901234567', 'trang.pham@shop.com', 'Kế toán');
INSERT INTO NhanVien VALUES ('NV02', 'Nguyễn Minh Thiện', 'Nam', 'Quận 7, HCM', '0908888999', 'thien.nguyen@shop.com', 'Bán hàng');


INSERT INTO SanPham VALUES ('IP15PM', 'H01', 'iPhone 15 Pro Max 256GB', 5, 'Titan Tự Nhiên', 30000000, 'Cái', 'Hàng chính hãng VN/A');
INSERT INTO SanPham VALUES ('S24U', 'H02', 'Samsung Galaxy S24 Ultra', 3, 'Xám Titan', 28000000, 'Cái', 'Kèm bút S-Pen');
INSERT INTO SanPham VALUES ('MI14', 'H03', 'Xiaomi 14 Ultra', 0, 'Đen', 25000000, 'Cái', 'Ống kính Leica');

INSERT INTO PNhap VALUES ('PN001', SYSDATE, 'NV01');
INSERT INTO PXuat VALUES ('PX001', SYSDATE, 'NV02');

COMMIT;

-- a. Trigger INSERT bảng NHAP – trg_Nhap
CREATE OR REPLACE TRIGGER trg_Nhap_Insert
AFTER INSERT ON Nhap
FOR EACH ROW
DECLARE
    v_Count INT;
BEGIN
    -- 1. Kiểm tra MaSP có tồn tại trong SanPham không
    SELECT COUNT(*) INTO v_Count FROM SanPham WHERE MaSP = :NEW.MaSP;
    IF v_Count = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Loi: Ma san pham ' || :NEW.MaSP || ' khong ton tai trong he thong!');
    END IF;

    -- 2. Kiểm tra ràng buộc dữ liệu (SoLuongN > 0 và DonGiaN > 0)
    IF :NEW.SoLuongN <= 0 OR :NEW.DonGiaN <= 0 THEN
        RAISE_APPLICATION_ERROR(-20002, 'Loi: So luong nhap va Don gia nhap phai lon hon 0!');
    END IF;

    -- 3. Cập nhật số lượng trong bảng SanPham
    UPDATE SanPham
    SET SoLuong = SoLuong + :NEW.SoLuongN
    WHERE MaSP = :NEW.MaSP;
    
    DBMS_OUTPUT.PUT_LINE('Cap nhat kho thanh cong cho san pham: ' || :NEW.MaSP);
END;
/

-- test TH1: Nhập hàng thành công
-- Xem số lượng trước khi nhập
SELECT MaSP, TenSP, SoLuong FROM SanPham WHERE MaSP = 'IP15PM';

-- Thực hiện nhập
INSERT INTO Nhap (SoHDN, MaSP, SoLuongN, DonGiaN) 
VALUES ('PN001', 'IP15PM', 10, 28000000);

-- Kiểm tra lại: SoLuong đã tăng thêm 10
SELECT MaSP, TenSP, SoLuong FROM SanPham WHERE MaSP = 'IP15PM';

-- TH2: Báo lỗi do sai MaSP (Ràng buộc toàn vẹn)
INSERT INTO Nhap (SoHDN, MaSP, SoLuongN, DonGiaN) 
VALUES ('PN001', 'IP99', 5, 10000000);

-- TH3: Báo lỗi do dữ liệu không hợp lệ (SoLuongN <= 0)
INSERT INTO Nhap (SoHDN, MaSP, SoLuongN, DonGiaN) 
VALUES ('PN001', 'IP15PM', -5, 28000000);

-- TH4: Báo lỗi do đơn giá không hợp lệ (DonGiaN <= 0)
INSERT INTO Nhap (SoHDN, MaSP, SoLuongN, DonGiaN) 
VALUES ('PN001', 'IP15PM', 10, 0);

-- b. Trigger INSERT bảng XUAT – trg_xuat
CREATE OR REPLACE TRIGGER trg_xuat
BEFORE INSERT ON Xuat
FOR EACH ROW
DECLARE
    v_dem NUMBER := 0;
    v_tonkho NUMBER := 0;
BEGIN
    -- 1. Kiểm tra MaSP có tồn tại trong bảng SanPham không?
    SELECT COUNT(*) INTO v_dem FROM SanPham WHERE MaSP = :NEW.MaSP;
    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Loi: Ma san pham khong ton tai!');
    END IF;

    -- 2. Kiểm tra hàng trong kho có đủ để xuất không?
    SELECT SoLuong INTO v_tonkho FROM SanPham WHERE MaSP = :NEW.MaSP;
    IF :NEW.SoLuongX > v_tonkho THEN
        RAISE_APPLICATION_ERROR(-20003, 'Loi: So luong xuat vuot qua ton kho (Hien co: ' || v_tonkho || ')');
    END IF;

    -- 3. Nếu hợp lệ -> Cập nhật SoLuong trong SanPham: SoLuong = SoLuong - SoLuongX
    UPDATE SanPham 
    SET SoLuong = SoLuong - :NEW.SoLuongX
    WHERE MaSP = :NEW.MaSP;
END;
/

-- test TH1: Nhập hàng thành công
-- Kiểm tra kho trước khi xuất
SELECT MaSP, TenSP, SoLuong FROM SanPham WHERE MaSP = 'IP15PM';

-- Thực hiện xuất 5 cái
INSERT INTO Xuat (SoHDX, MaSP, SoLuongX) VALUES ('PX001', 'IP15PM', 5);

-- Ktra lại: Kho chỉ còn 10 cái
SELECT MaSP, TenSP, SoLuong FROM SanPham WHERE MaSP = 'IP15PM';

-- TH2: Lỗi "Cháy hàng" (Xuất quá số lượng tồn)
INSERT INTO Xuat (SoHDX, MaSP, SoLuongX) VALUES ('PX001', 'IP15PM', 100);


-- TH3: Lỗi sai mã sản phẩm (Ràng buộc toàn vẹn)
INSERT INTO Xuat (SoHDX, MaSP, SoLuongX) VALUES ('PX001', 'GALAXY_S99', 1);

-- c. Trigger DELETE bảng XUAT – trg_XoaXuat
CREATE OR REPLACE TRIGGER trg_XoaXuat
AFTER DELETE ON Xuat
FOR EACH ROW
BEGIN
    -- Khi phiếu xuất bị xóa -> Hoàn trả số lượng vào bảng SanPham
    UPDATE SanPham
    SET SoLuong = SoLuong + :OLD.SoLuongX
    WHERE MaSP = :OLD.MaSP;
    
    DBMS_OUTPUT.PUT_LINE('Da hoan tra ' || :OLD.SoLuongX || ' san pham vao kho.');
END;
/
 -- TH1: Kiểm tra kho và Bán hàng để tạo dl
 -- Xem số lượng iPhone hiện tại 
SELECT MaSP, SoLuong FROM SanPham WHERE MaSP = 'IP15PM';

INSERT INTO PXuat (SoHDX, NgayXuat, MaNV) VALUES ('PX_TEST_02', SYSDATE, 'NV01');
INSERT INTO Xuat (SoHDX, MaSP, SoLuongX) VALUES ('PX_TEST_02', 'IP15PM', 3);
COMMIT;

-- Bán đi 3 cái
INSERT INTO Xuat (SoHDX, MaSP, SoLuongX) VALUES ('PX_TEST', 'IP15PM', 3);

-- Kiểm tra lại: Kho còn 4 cái (Do Trigger vừa chạy)
SELECT MaSP, SoLuong FROM SanPham WHERE MaSP = 'IP15PM';

-- TH2: Xóa dòng vừa bán
-- Xóa dòng xuất hàng
DELETE FROM Xuat WHERE SoHDX = 'PX_TEST' AND MaSP = 'IP15PM';

-- Kiểm tra kết quả cuối cùng: Kho phải quay về 7 cái
SELECT MaSP, SoLuong FROM SanPham WHERE MaSP = 'IP15PM';

-- PHIẾU BT2
CREATE OR REPLACE PACKAGE pkg_state AS
    g_row_count NUMBER := 0;
END pkg_state;
/

-- a. Trigger UPDATE bảng XUAT – trg_CapNhatXuat
CREATE OR REPLACE TRIGGER trg_CapNhatXuat
FOR UPDATE ON Xuat
COMPOUND TRIGGER
    BEFORE STATEMENT IS
    BEGIN
        pkg_state.g_row_count := 0; -- Reset đếm
    END BEFORE STATEMENT;

    BEFORE EACH ROW IS
        v_ton NUMBER;
    BEGIN
        pkg_state.g_row_count := pkg_state.g_row_count + 1;
        -- 1. Kiểm tra số bản ghi > 1
        IF pkg_state.g_row_count > 1 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Loi: Chi duoc cap nhat 1 ban ghi moi lan!');
        END IF;

        -- 2. Kiểm tra kho nếu SoLuongX thay đổi
        IF :NEW.SoLuongX <> :OLD.SoLuongX THEN
            SELECT SoLuong INTO v_ton FROM SanPham WHERE MaSP = :NEW.MaSP;
            IF v_ton < (:NEW.SoLuongX - :OLD.SoLuongX) THEN
                RAISE_APPLICATION_ERROR(-20002, 'Loi: Khong du hang de bu chenh lech!');
            END IF;

            -- 3. Cập nhật SanPham: SoLuong = SoLuong - (Mới - Cũ)
            UPDATE SanPham 
            SET SoLuong = SoLuong - (:NEW.SoLuongX - :OLD.SoLuongX)
            WHERE MaSP = :NEW.MaSP;
        END IF;
    END BEFORE EACH ROW;
END;
/

-- dl mẫu
INSERT INTO PXuat (SoHDX, NgayXuat, MaNV) VALUES ('PX_TEST_2', SYSDATE, 'NV01');
INSERT INTO Xuat (SoHDX, MaSP, SoLuongX) VALUES ('PX_TEST_2', 'IP15PM', 3);
COMMIT;

-- Trường hợp 1: Test thành công (Sửa lượng bán)
-- 1. Xem kho trước 
SELECT SoLuong FROM SanPham WHERE MaSP = 'IP15PM';
-- 2. Cập nhật: Sửa từ 3 lên 5 (Bán thêm 2 cái -> Kho phải giảm đi 2)
UPDATE Xuat 
SET SoLuongX = 5 
WHERE SoHDX = 'PX_TEST_2' AND MaSP = 'IP15PM';
-- 3. Kiểm tra kho sau khi update: Kho mới = Kho cũ - 2
SELECT SoLuong FROM SanPham WHERE MaSP = 'IP15PM';

-- Trường hợp 2: Test lỗi "Không đủ hàng"
UPDATE Xuat 
SET SoLuongX = 1000 
WHERE SoHDX = 'PX_TEST_2' AND MaSP = 'IP15PM';

-- Trường hợp 3: Test lỗi sửa nhiều dòng
UPDATE Xuat SET SoLuongX = 1;

-- b. Trigger UPDATE bảng NHAP – trg_CapNhatNhap
CREATE OR REPLACE TRIGGER trg_CapNhatNhap
FOR UPDATE ON Nhap
COMPOUND TRIGGER
    BEFORE STATEMENT IS
    BEGIN
        pkg_state.g_row_count := 0;
    END BEFORE STATEMENT;

    BEFORE EACH ROW IS
    BEGIN
        pkg_state.g_row_count := pkg_state.g_row_count + 1;
        IF pkg_state.g_row_count > 1 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Loi: Chi duoc cap nhat 1 ban ghi!');
        END IF;

        -- Cập nhật SanPham: SoLuong = SoLuong + (Mới - Cũ)
        IF :NEW.SoLuongN <> :OLD.SoLuongN THEN
            UPDATE SanPham 
            SET SoLuong = SoLuong + (:NEW.SoLuongN - :OLD.SoLuongN)
            WHERE MaSP = :NEW.MaSP;
        END IF;
    END BEFORE EACH ROW;
END;
/

-- Tạo dữ liệu mẫu
INSERT INTO PNhap (SoHDN, NgayNhap, MaNV) VALUES ('PN_TEST', SYSDATE, 'NV01');
INSERT INTO Nhap (SoHDN, MaSP, SoLuongN, DonGiaN) VALUES ('PN_TEST', 'IP15PM', 10, 28000000);
COMMIT;

-- Sửa nhập hàng
-- Sửa từ nhập 10 thành nhập 12 (Kho sẽ tăng thêm 2)
UPDATE Nhap SET SoLuongN = 12 WHERE SoHDN = 'PN_TEST' AND MaSP = 'IP15PM';
-- Kiểm tra kho
SELECT SoLuong FROM SanPham WHERE MaSP = 'IP15PM';

-- Test lỗi Compound (Sửa nhiều dòng)
-- Lệnh này sửa cả bảng, Trigger PHẢI báo lỗi ORA-20001
UPDATE Nhap SET SoLuongN = 20;

-- c. Trigger DELETE bảng NHAP – trg_XoaNhap
CREATE OR REPLACE TRIGGER trg_XoaNhap
AFTER DELETE ON Nhap
FOR EACH ROW
BEGIN
    UPDATE SanPham
    SET SoLuong = SoLuong - :OLD.SoLuongN
    WHERE MaSP = :OLD.MaSP;
END;
/

-- Xóa nhập hàng
-- Xóa phiếu vừa rồi, kho phải trừ đi 12 cái
DELETE FROM Nhap WHERE SoHDN = 'PN_TEST';
-- Kiểm tra kho lần cuối
SELECT SoLuong FROM SanPham WHERE MaSP = 'IP15PM';
