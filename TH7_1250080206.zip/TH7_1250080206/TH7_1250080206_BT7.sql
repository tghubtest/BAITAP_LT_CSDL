CREATE TABLE KHOA (
    Makhoa VARCHAR2(10) PRIMARY KEY,
    Tenkhoa VARCHAR2(100),
    Dienthoai VARCHAR2(20)
);

CREATE TABLE LOP (
    Malop VARCHAR2(10) PRIMARY KEY,
    Tenlop VARCHAR2(100),
    Khoa VARCHAR2(50),
    Hedt VARCHAR2(50),
    Namnhaphoc NUMBER,
    Makhoa VARCHAR2(10) REFERENCES KHOA(Makhoa)
);

-- BÀI TẬP 1
CREATE OR REPLACE PROCEDURE Nhap_dl_Khoa (
    p_makhoa    IN VARCHAR2, -- tham số đầu vào
    p_tenkhoa   IN VARCHAR2, 
    p_dienthoai IN VARCHAR2
) AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM KHOA WHERE Tenkhoa = p_tenkhoa;
    IF v_dem > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Thong bao: Ten khoa ' || p_tenkhoa || ' da ton tai!'); -- xử lý khi đúng
    ELSE
        INSERT INTO KHOA (Makhoa, Tenkhoa, Dienthoai) 
        VALUES (p_makhoa, p_tenkhoa, p_dienthoai);
        COMMIT; 
        DBMS_OUTPUT.PUT_LINE('Ket qua: Da them khoa ' || p_tenkhoa || ' thanh cong.');
    END IF;
END Nhap_dl_Khoa;
/

-- Xuất ra tb màn hình: test vs 2 trw hợp
SET SERVEROUTPUT ON;
-- cách 1: Anonymous block 
-- TH1
BEGIN
   Nhap_dl_Khoa('K01', 'Cong nghe thong tin', '0123456');
END;
/
-- TH2
BEGIN
    Nhap_dl_Khoa('K02', 'Cong nghe thong tin', '0999888'); 
END;
/

-- BÀI TẬP 2
CREATE OR REPLACE PROCEDURE Nhap_dl_Lop (
    p_malop      IN VARCHAR2, -- tham số đầu vào
    p_tenlop     IN VARCHAR2,
    p_khoa       IN VARCHAR2,
    p_hedt       IN VARCHAR2,
    p_namnhaphoc IN NUMBER,
    p_makhoa     IN VARCHAR2
) AS
    v_dem_lop  NUMBER := 0;
    v_dem_khoa NUMBER := 0;
BEGIN
    -- Ktra tên lớp đã có chưa
    SELECT COUNT(*) INTO v_dem_lop FROM LOP WHERE Tenlop = p_tenlop;
    -- Ktra mã khoa có tồn tại trong bảng KHOA không
    SELECT COUNT(*) INTO v_dem_khoa FROM KHOA WHERE Makhoa = p_makhoa;

    IF v_dem_lop > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Thong bao: Ten lop ' || p_tenlop || ' da ton tai!');
    ELSIF v_dem_khoa = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Thong bao: Ma khoa ' || p_makhoa || ' khong ton tai trong bang KHOA!');
    ELSE
        -- Nếu đầu đủ thông tin thì cho nhập
        INSERT INTO LOP (Malop, Tenlop, Khoa, Hedt, Namnhaphoc, Makhoa)
        VALUES (p_malop, p_tenlop, p_khoa, p_hedt, p_namnhaphoc, p_makhoa);
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Ket qua: Da them lop ' || p_tenlop || ' thanh cong.');
    END IF;
END Nhap_dl_Lop;
/

-- Test thử Bài 2
BEGIN
    Nhap_dl_Lop('L01', 'Lop CNTT 4', 'CNTT', 'Dai hoc', 2026, 'K01');
END;
/

BEGIN
    Nhap_dl_Lop('L01', 'Lop CNTT 4', 'CNTT', 'Dai hoc', 2026, 'KHOA_AO');
END;
/

BEGIN
    Nhap_dl_Lop('L02', 'Lop CNTT2', 'CNTT', 'Dai hoc', 2025, 'KHOA_AO');
END;
/

-- BÀI TẬP 3
CREATE OR REPLACE PROCEDURE Nhap_dl_Khoa_OUT (
    p_makhoa    IN VARCHAR2,
    p_tenkhoa   IN VARCHAR2,
    p_dienthoai IN VARCHAR2,
    p_ketqua    OUT NUMBER -- tham số đầu ra để nhận giá trị 0 hoặc 1
) AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM KHOA WHERE Tenkhoa = p_tenkhoa;
    IF v_dem > 0 THEN
        p_ketqua := 0; -- Trả về 0 nếu đã tồn tại
    ELSE
        INSERT INTO KHOA VALUES (p_makhoa, p_tenkhoa, p_dienthoai);
        COMMIT;
        p_ketqua := 1; -- Trả về 1 nếu thành công
    END IF;
END Nhap_dl_Khoa_OUT;
/

-- Test 2 trw hợp (Cách 2: khi có tham số OUT cần khai bái biến nhận)
DECLARE
    v_kq NUMBER;
BEGIN
    -- Gọi thủ tục với thông tin khoa chưa có
    Nhap_dl_Khoa_OUT('K04', 'Sư phạm', '0111222', v_kq);
    DBMS_OUTPUT.PUT_LINE('Truong hop 1 - Nhap moi: Ket qua tra ve = ' || v_kq);
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    -- Thử nhập lại tên 'Sư phạm' nhưng mã khoa khác (K05)
    Nhap_dl_Khoa_OUT('K05', 'Sư phạm', '0333444', v_kq);
    
    -- In kết quả ra màn hình
    DBMS_OUTPUT.PUT_LINE('Truong hop 2 - Trung ten: Ket qua tra ve = ' || v_kq);
END;
/

-- BÀI TẬP 4
CREATE OR REPLACE PROCEDURE Nhap_dl_Lop_OUT (
    p_malop      IN VARCHAR2,
    p_tenlop     IN VARCHAR2,
    p_khoa       IN VARCHAR2,
    p_hedt       IN VARCHAR2,
    p_namnhaphoc IN NUMBER,
    p_makhoa     IN VARCHAR2,
    p_ketqua     OUT NUMBER -- tham số đầu ra
) AS
    v_check_lop  NUMBER := 0;
    v_check_khoa NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_check_lop FROM LOP WHERE Tenlop = p_tenlop;
    SELECT COUNT(*) INTO v_check_khoa FROM KHOA WHERE Makhoa = p_makhoa;

    IF v_check_lop > 0 THEN
        p_ketqua := 0; -- Tên lớp đã có
    ELSIF v_check_khoa = 0 THEN
        p_ketqua := 1; -- Mã khoa không có
    ELSE
        INSERT INTO LOP VALUES (p_malop, p_tenlop, p_khoa, p_hedt, p_namnhaphoc, p_makhoa);
        COMMIT;
        p_ketqua := 2; -- Thành công
    END IF;
END Nhap_dl_Lop_OUT;
/

-- Test Bài 4
DECLARE
    v_ketqua NUMBER;
BEGIN
    Nhap_dl_Lop_OUT('L02', 'Lop Co ban', 'K1', 'Cao dang', 2024, 'K01', v_ketqua);
    DBMS_OUTPUT.PUT_LINE('Ket qua Bai 4: ' || v_ketqua);
END;
/