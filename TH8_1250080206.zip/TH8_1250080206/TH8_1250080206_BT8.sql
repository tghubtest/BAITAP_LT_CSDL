CREATE TABLE HangSX (
    MaHangSX VARCHAR2(10) CONSTRAINT pk_hangsx PRIMARY KEY,
    TenHang VARCHAR2(30) NOT NULL,
    DiaChi VARCHAR2(50),
    SoDT VARCHAR2(15),
    Email VARCHAR2(50)
);

CREATE TABLE SanPham (
    MaSP VARCHAR2(10) CONSTRAINT pk_sanpham PRIMARY KEY,
    MaHangSX VARCHAR2(10) REFERENCES HangSX(MaHangSX),
    TenSP VARCHAR2(50) NOT NULL,
    SoLuong NUMBER(10),
    MauSac VARCHAR2(20),
    GiaBan NUMBER(15,2),
    DonViTinh VARCHAR2(15),
    MoTa CLOB
);

CREATE TABLE NhanVien (
    MaNV VARCHAR2(10) CONSTRAINT pk_nhanvien PRIMARY KEY,
    TenNV VARCHAR2(50) NOT NULL,
    GioiTinh VARCHAR2(10),
    DiaChi VARCHAR2(100),
    SoDT VARCHAR2(15),
    Email VARCHAR2(50),
    TenPhong VARCHAR2(30)
);

CREATE TABLE PNhap (
    SoHDN VARCHAR2(10) CONSTRAINT pk_pnhap PRIMARY KEY,
    NgayNhap DATE,
    MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV)
);

CREATE TABLE Nhap (
    SoHDN VARCHAR2(10) REFERENCES PNhap(SoHDN),
    MaSP VARCHAR2(10) REFERENCES SanPham(MaSP),
    SoLuongN NUMBER(10),
    DonGiaN NUMBER(15,2),
    CONSTRAINT pk_nhap PRIMARY KEY (SoHDN, MaSP)
);

CREATE TABLE PXuat (
    SoHDX VARCHAR2(10) CONSTRAINT pk_pxuat PRIMARY KEY,
    NgayXuat DATE,
    MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV)
);

CREATE TABLE Xuat (
    SoHDX VARCHAR2(10) REFERENCES PXuat(SoHDX),
    MaSP VARCHAR2(10) REFERENCES SanPham(MaSP),
    SoLuongX NUMBER(10),
    CONSTRAINT pk_xuat PRIMARY KEY (SoHDX, MaSP)
);

DROP TABLE Xuat CASCADE CONSTRAINTS;
DROP TABLE Nhap CASCADE CONSTRAINTS;
DROP TABLE PXuat CASCADE CONSTRAINTS;
DROP TABLE PNhap CASCADE CONSTRAINTS;
DROP TABLE NhanVien CASCADE CONSTRAINTS;
DROP TABLE SanPham CASCADE CONSTRAINTS;
DROP TABLE HangSX CASCADE CONSTRAINTS;

-- a. Thủ tục sp_NhapHangSX
CREATE OR REPLACE PROCEDURE sp_NhapHangSX (
    p_mahangsx IN VARCHAR2,
    p_tenhang   IN VARCHAR2,
    p_diachi    IN VARCHAR2,
    p_sodt      IN VARCHAR2,
    p_email     IN VARCHAR2
) AS
    v_dem NUMBER := 0; -- Biến cục bộ để đếm
BEGIN
    SELECT COUNT(*) INTO v_dem FROM HangSX WHERE TenHang = p_tenhang;
    IF v_dem > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Thong bao: Ten hang ' || p_tenhang || ' da ton tai!');
    ELSE
        INSERT INTO HangSX VALUES (p_mahangsx, p_tenhang, p_diachi, p_sodt, p_email);
        COMMIT; -- Lưu thay đổi
        DBMS_OUTPUT.PUT_LINE('Ket qua: Da them hang thanh cong.');
    END IF;
END sp_NhapHangSX;
/
-- test
SET SERVEROUTPUT ON;
BEGIN
   sp_NhapHangSX('H01', 'Samsung', 'Han Quoc', '0123', 'ss@mail.com');
END;
/
-- thêm dl ms
BEGIN
   sp_NhapHangSX('H02', 'Iphone', 'My', '0999', 'test@mail.com');
END;
/
SELECT * FROM HangSX;

-- b. Thủ tục sp_NhapSP
CREATE OR REPLACE PROCEDURE sp_NhapSP (
    p_masp      IN VARCHAR2,
    p_tenhang   IN VARCHAR2,
    p_tensp     IN VARCHAR2,
    p_soluong   IN NUMBER,
    p_mausac    IN VARCHAR2,
    p_giaban    IN NUMBER,
    p_donvitinh IN VARCHAR2,
    p_mota      IN CLOB
) AS
    v_mahang VARCHAR2(10);
    v_dem_h  NUMBER := 0;
    v_dem_sp NUMBER := 0;
BEGIN
    -- Lấy mã hãng từ tên hãng
    SELECT COUNT(*) INTO v_dem_h FROM HangSX WHERE TenHang = p_tenhang;
    IF v_dem_h = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Thong bao: Khong tim thay hang ' || p_tenhang);
    ELSE
        SELECT MaHangSX INTO v_mahang FROM HangSX WHERE TenHang = p_tenhang;
        SELECT COUNT(*) INTO v_dem_sp FROM SanPham WHERE MaSP = p_masp;
        IF v_dem_sp > 0 THEN
            UPDATE SanPham SET MaHangSX = v_mahang, TenSP = p_tensp, SoLuong = p_soluong, 
                               MauSac = p_mausac, GiaBan = p_giaban, DonViTinh = p_donvitinh, MoTa = p_mota
            WHERE MaSP = p_masp;
            DBMS_OUTPUT.PUT_LINE('Ket qua: Da cap nhat san pham.');
        ELSE
            INSERT INTO SanPham VALUES (p_masp, v_mahang, p_tensp, p_soluong, p_mausac, p_giaban, p_donvitinh, p_mota);
            DBMS_OUTPUT.PUT_LINE('Ket qua: Da them san pham moi.');
        END IF;
        COMMIT;
    END IF;
END sp_NhapSP;
/
-- test
BEGIN
   sp_NhapSP('S01', 'Apple', 'iPhone 15', 10, 'Titan', 25000000, 'Chiec', 'New');
END;
/
-- thêm sp ms
BEGIN
   sp_NhapSP('S24', 'Samsung', 'Galaxy S24', 50, 'Black', 20000000, 'Chiec', 'Flagship');
END;
/
-- cập nhật (máy tự Update vì trùng mã S24)
BEGIN
   sp_NhapSP('S24', 'Samsung', 'Galaxy S24 Ultra', 30, 'Gray', 28000000, 'Chiec', 'Premium');
END;
/
-- c. Thủ tục sp_xoaHangSX
CREATE OR REPLACE PROCEDURE sp_xoaHangSX (p_tenhang IN VARCHAR2) AS
    v_mahang VARCHAR2(10);
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM HangSX WHERE TenHang = p_tenhang;
    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Thong bao: Ten hang khong ton tai.');
    ELSE
        SELECT MaHangSX INTO v_mahang FROM HangSX WHERE TenHang = p_tenhang;
        DELETE FROM SanPham WHERE MaHangSX = v_mahang; -- Xóa con trước
        DELETE FROM HangSX WHERE MaHangSX = v_mahang;  -- Xóa cha sau
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Ket qua: Da xoa hang va cac san pham lien quan.');
    END IF;
END sp_xoaHangSX;
/
-- TenHang chưa có → thông báo.
BEGIN
   sp_xoaHangSX('Nokia');
END;
/
-- Nếu có → xóa tất cả SanPham của hãng đó trước,rồi xóa HangSX.
BEGIN
   sp_xoaHangSX('Samsung');
END;
/

-- d. Thủ tục nhập dữ liệu NhanVien (có biến FLAG)
CREATE OR REPLACE PROCEDURE sp_NhapNhanVien (
    p_manv IN VARCHAR2, p_tennv IN VARCHAR2, p_gioitinh IN VARCHAR2,
    p_diachi IN VARCHAR2, p_sodt IN VARCHAR2, p_email IN VARCHAR2,
    p_tenphong IN VARCHAR2, p_flag IN NUMBER 
) AS
BEGIN
    IF p_flag = 0 THEN
        UPDATE NhanVien SET TenNV = p_tennv, GioiTinh = p_gioitinh, DiaChi = p_diachi,
                            SoDT = p_sodt, Email = p_email, TenPhong = p_tenphong
        WHERE MaNV = p_manv;
        DBMS_OUTPUT.PUT_LINE('Ket qua: Da cap nhat nhan vien.');
    ELSE
        INSERT INTO NhanVien VALUES (p_manv, p_tennv, p_gioitinh, p_diachi, p_sodt, p_email, p_tenphong);
        DBMS_OUTPUT.PUT_LINE('Ket qua: Da them nhan vien moi.');
    END IF;
    COMMIT;
END sp_NhapNhanVien;
/
-- Thêm mới (Flag = 1)
BEGIN
   sp_NhapNhanVien('NV01', 'Nguyen Van A', 'Nam', 'Ha Noi', '0912', 'a@mail.com', 'Kinh doanh', 1);
END;
/
-- Cập nhật (Flag = 0)
BEGIN
   sp_NhapNhanVien('NV01', 'Nguyen Van Trang', 'Nu', 'HCM', '0912', 'trang@mail.com', 'Ke toan', 0);
END;
/

-- e. Thủ tục nhập dữ liệu bảng Nhap
CREATE OR REPLACE PROCEDURE sp_NhapDLNhap (
    p_sohdn IN VARCHAR2, p_masp IN VARCHAR2, p_manv IN VARCHAR2,
    p_ngay IN DATE, p_sl IN NUMBER, p_dg IN NUMBER
) AS
    v_c_sp NUMBER; v_c_nv NUMBER; v_c_hd NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_c_sp FROM SanPham WHERE MaSP = p_masp;
    SELECT COUNT(*) INTO v_c_nv FROM NhanVien WHERE MaNV = p_manv;
    IF v_c_sp = 0 THEN DBMS_OUTPUT.PUT_LINE('Loi: Ma SP khong co.');
    ELSIF v_c_nv = 0 THEN DBMS_OUTPUT.PUT_LINE('Loi: Ma NV khong co.');
    ELSE
        SELECT COUNT(*) INTO v_c_hd FROM PNhap WHERE SoHDN = p_sohdn;
        IF v_c_hd > 0 THEN
            UPDATE Nhap SET SoLuongN = p_sl, DonGiaN = p_dg WHERE SoHDN = p_sohdn AND MaSP = p_masp;
        ELSE
            INSERT INTO PNhap VALUES (p_sohdn, p_ngay, p_manv);
            INSERT INTO Nhap VALUES (p_sohdn, p_masp, p_sl, p_dg);
        END IF;
        COMMIT;
    END IF;
END;
/
-- Kiểm tra MaSP có trong bảng SanPham không → nếu không, thông báo.
BEGIN
   sp_NhapDLNhap('HDN01', 'OPPO', 'NV01', SYSDATE, 10, 15000000);
END;
/
-- Kiểm tra MaNV có trong bảng NhanVien không → nếu không, thông báo.
BEGIN
   sp_NhapDLNhap('HDN01', 'S24', 'NV999', SYSDATE, 10, 15000000);
END;
/
-- Nếu SoHDN chưa tồn tại → INSERT mới vào Nhap và PNhap.
BEGIN
   sp_NhapDLNhap('HDN01', 'S24', 'NV01', SYSDATE, 10, 15000000);
END;
/
-- Nếu SoHDN đã tồn tại → cập nhật bảng Nhap theo SoHDN.
BEGIN
   -- Cập nhật số lượng lên 50 và giá lên 16tr cho HDN01
   sp_NhapDLNhap('HDN01', 'S24', 'NV01', SYSDATE, 50, 16000000);
END;
/
SELECT * FROM PNhap; -- Ktra có HDN01 chưa
SELECT * FROM Nhap;  -- Ktra xem SoLuongN đã cập nhật thành 50 ch

-- f. Thủ tục nhập dữ liệu bảng Xuat
CREATE OR REPLACE PROCEDURE sp_NhapDLXuat (
    p_sohdx IN VARCHAR2, p_masp IN VARCHAR2, p_manv IN VARCHAR2,
    p_ngay IN DATE, p_slx IN NUMBER
) AS
    v_ton NUMBER; v_c_hd NUMBER;
BEGIN
    -- Kiểm tra tồn kho
    SELECT SoLuong INTO v_ton FROM SanPham WHERE MaSP = p_masp;
    IF p_slx > v_ton THEN
        DBMS_OUTPUT.PUT_LINE('Thong bao: Khong du hang de xuat.');
    ELSE
        SELECT COUNT(*) INTO v_c_hd FROM PXuat WHERE SoHDX = p_sohdx;
        IF v_c_hd > 0 THEN
            UPDATE Xuat SET SoLuongX = p_slx WHERE SoHDX = p_sohdx AND MaSP = p_masp;
        ELSE
            INSERT INTO PXuat VALUES (p_sohdx, p_ngay, p_manv);
            INSERT INTO Xuat VALUES (p_sohdx, p_masp, p_slx);
        END IF;
        COMMIT;
    END IF;
END;
/

BEGIN
   sp_NhapNhanVien('NV01', 'Nguyen Van A', 'Nam', 'Ha Noi', '0123', 'a@mail.com', 'Kinh doanh', 1);
   sp_NhapHangSX('H01', 'Samsung', 'Korea', '0123', 'ss@mail.com');
   sp_NhapSP('S24', 'Samsung', 'Galaxy S24', 100, 'Black', 20000000, 'Chiec', 'New');
END;
/
-- Kiểm tra MaSP có trong bảng SanPham không → nếu không, thông báo.
BEGIN
   sp_NhapDLXuat('HDX01', 'ABC', 'NV01', SYSDATE, 5);
END;
/
-- Kiểm tra MaNV có trong bảng NhanVien không → nếu không, thông báo.
BEGIN
   sp_NhapDLXuat('HDX01', 'S24', 'NV_LA', SYSDATE, 5);
END;
/
-- Kiểm tra SoLuongX <= SoLuong trong bảng SanPham → nếu không, thông báo.
BEGIN
   sp_NhapDLXuat('HDX01', 'S24', 'NV01', SYSDATE, 100);
END;
/
-- Xuất thành công
BEGIN
   sp_NhapDLXuat('HDX01', 'S24', 'NV01', SYSDATE, 5);
END;
/
-- Nếu SoHDX đã tồn tại → cập nhật bảng Xuat. 
BEGIN
   -- Sửa lại số lượng xuất của hóa đơn HDX01 từ 5 cái thành 10 cái
   sp_NhapDLXuat('HDX01', 'S24', 'NV01', SYSDATE, 10);
END;
/
-- Ngược lại → INSERT mới.
BEGIN
   sp_NhapDLXuat('HDX_NEW_01', 'S24', 'NV01', SYSDATE, 5);
END;
/
-- g. Thủ tục xóa NhanVien
CREATE OR REPLACE PROCEDURE sp_xoaNhanVien (p_manv IN VARCHAR2) AS
    v_dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM NhanVien WHERE MaNV = p_manv;
    IF v_dem = 0 THEN DBMS_OUTPUT.PUT_LINE('Khong tim thay NV.');
    ELSE
        -- Xóa con của PNhap và PXuat trước
        DELETE FROM Nhap WHERE SoHDN IN (SELECT SoHDN FROM PNhap WHERE MaNV = p_manv);
        DELETE FROM Xuat WHERE SoHDX IN (SELECT SoHDX FROM PXuat WHERE MaNV = p_manv);
        DELETE FROM PNhap WHERE MaNV = p_manv;
        DELETE FROM PXuat WHERE MaNV = p_manv;
        DELETE FROM NhanVien WHERE MaNV = p_manv;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Da xoa nhan vien va cac hoa don lien quan.');
    END IF;
END;
/
-- MaNV chưa có → thông báo.
BEGIN
   sp_xoaNhanVien('NV02');
END;
/
-- Xóa nhân viên
BEGIN
   sp_xoaNhanVien('NV01');
END;
/

-- h. Thủ tục xóa SanPham
CREATE OR REPLACE PROCEDURE sp_xoaSanPham (p_masp IN VARCHAR2) AS
    v_dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM SanPham WHERE MaSP = p_masp;
    IF v_dem = 0 THEN DBMS_OUTPUT.PUT_LINE('Khong co San Pham nay.');
    ELSE
        DELETE FROM Nhap WHERE MaSP = p_masp; --
        DELETE FROM Xuat WHERE MaSP = p_masp;
        DELETE FROM SanPham WHERE MaSP = p_masp;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Da xoa san pham thanh cong.');
    END IF;
END;
/

