CREATE TABLE HANG (
    Mahang VARCHAR2(10) PRIMARY KEY,
    Tenhang VARCHAR2(50),
    Soluong NUMBER(10),
    Giaban NUMBER(15,2)
);

CREATE TABLE HOADON (
    Mahd VARCHAR2(10) PRIMARY KEY,
    Mahang VARCHAR2(10) REFERENCES HANG(Mahang),
    Soluongban NUMBER(10),
    Ngayban DATE
);

INSERT INTO HANG VALUES ('H01', 'Ti vi Sony', 10, 5000000);
INSERT INTO HANG VALUES ('H02', 'Tu lanh LG', 5, 3000000);
COMMIT;

-- Bài 1: Kiểm tra hàng tồn tại, kiểm tra số lượng và trừ kho
CREATE OR REPLACE TRIGGER trg_Bai1_Insert
BEFORE INSERT ON HOADON
FOR EACH ROW
DECLARE
    v_soluong_ton NUMBER := 0;
    v_count NUMBER := 0;
BEGIN
    -- Kiểm tra Mahang có tồn tại trong bảng HANG không?
    SELECT COUNT(*) INTO v_count FROM HANG WHERE Mahang = :NEW.Mahang;
    
    IF v_count = 0 THEN
        -- Nếu không tồn tại -> Thông báo lỗi và hủy giao dịch
        RAISE_APPLICATION_ERROR(-20001, 'Loi: Ma hang nay khong ton tai trong he thong!');
    END IF;

    --  Kiểm tra Soluongban <= Soluong tồn kho?
    SELECT Soluong INTO v_soluong_ton FROM HANG WHERE Mahang = :NEW.Mahang;
    
    IF :NEW.Soluongban > v_soluong_ton THEN
        -- Nếu bán nhiều hơn tồn kho -> Thông báo lỗi và hủy giao dịch
        RAISE_APPLICATION_ERROR(-20002, 'Loi: Khong du hang trong kho de ban!');
    END IF;

    --  Nếu thỏa mãn hết các điều kiện trên -> UPDATE giảm kho
    UPDATE HANG 
    SET Soluong = Soluong - :NEW.Soluongban
    WHERE Mahang = :NEW.Mahang;
    
    -- 0 cần COMMIT trong trigger vì nó sẽ đi theo giao dịch chính
END;
/

-- test mã hàng không tồn tại
INSERT INTO HOADON (Mahd, Mahang, Soluongban, Ngayban) 
VALUES ('HD_TEST1', 'H999', 1, SYSDATE);

-- Giả sử món H01 chỉ còn 10 cái, nhưng mình đòi mua 100 cái
INSERT INTO HOADON (Mahd, Mahang, Soluongban, Ngayban) 
VALUES ('HD_TEST2', 'H01', 100, SYSDATE);


-- bán thành công -> trừ kho
INSERT INTO HOADON (Mahd, Mahang, Soluongban, Ngayban) 
VALUES ('HD_OK', 'H01', 2, SYSDATE);
-- ktra lại bảng HANG xem Soluong có giảm đi 2 không
SELECT * FROM HANG WHERE Mahang = 'H01';


CREATE OR REPLACE TRIGGER trg_Bai2_Delete
AFTER DELETE ON HOADON
FOR EACH ROW
BEGIN
    -- Cộng lại số lượng vào kho khi xóa hóa đơn
    UPDATE HANG
    SET Soluong = Soluong + :OLD.Soluongban
    WHERE Mahang = :OLD.Mahang;
END;
/

-- Bài 3: Cập nhật lại kho dựa trên chênh lệch giữa số lượng mới và cũ
CREATE OR REPLACE TRIGGER trg_Bai3_Update
AFTER UPDATE ON HOADON
FOR EACH ROW
BEGIN
    -- Soluong = Soluong - (Moi - Cu)
    UPDATE HANG
    SET Soluong = Soluong - (:NEW.Soluongban - :OLD.Soluongban)
    WHERE Mahang = :NEW.Mahang;
END;
/

-- Sửa hóa đơn từ 2 lên 8
UPDATE HOADON SET Soluongban = 8 WHERE Mahd = 'HD001';
-- Kiểm tra kết quả
SELECT * FROM HANG WHERE Mahang = 'H01';


-- Bài 2: Khi xóa hóa đơn thì phải trả lại số lượng hàng về kho
CREATE OR REPLACE TRIGGER trg_Bai2_Delete
AFTER DELETE ON HOADON
FOR EACH ROW
BEGIN
    -- Cộng lại số lượng vào kho khi xóa hóa đơn
    UPDATE HANG
    SET Soluong = Soluong + :OLD.Soluongban
    WHERE Mahang = :OLD.Mahang;
END;
/
-- ktra sl
SELECT Mahang, Soluong FROM HANG WHERE Mahang = 'H01';
-- xóa hd
DELETE FROM HOADON WHERE Mahd = 'HD_OK';
-- ktra lại
SELECT Mahang, Soluong FROM HANG WHERE Mahang = 'H01';

CREATE TABLE Mathang (
Mahang VARCHAR2(5) CONSTRAINT pk_mathang PRIMARY KEY,
Tenhang VARCHAR2(50) NOT NULL,
Soluong NUMBER(10)
);
CREATE TABLE Nhatkybanhang (
Stt NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
Ngay DATE,
Nguoimua VARCHAR2(50),
Mahang VARCHAR2(5) REFERENCES Mathang(Mahang),
Soluong NUMBER(10),
Giaban NUMBER(15,2)
);
-- Dữ liệu mẫu Mathang
INSERT INTO Mathang VALUES ('1','Hang A', 100);
INSERT INTO Mathang VALUES ('2','Hang B', 200);
INSERT INTO Mathang VALUES ('3','Hang C', 150);
COMMIT;

-- a. Khi bán hàng (INSERT), tự động giảm số lượng trong kho
CREATE OR REPLACE TRIGGER trg_nhatkybanhang_insert
AFTER INSERT ON Nhatkybanhang
FOR EACH ROW
BEGIN
    UPDATE Mathang
    SET Soluong = Soluong - :NEW.Soluong
    WHERE Mahang = :NEW.Mahang;
END;
/

-- Thử bán 10 cái 'Hang A' (Mã hàng là '1')
INSERT INTO Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban)
VALUES (SYSDATE, 'Nguyen Van Trang', '1', 10, 50000);

-- Ktra bảng Mathang mã '1' có giảm từ 100 xuống 90 không
SELECT * FROM Mathang WHERE Mahang = '1';